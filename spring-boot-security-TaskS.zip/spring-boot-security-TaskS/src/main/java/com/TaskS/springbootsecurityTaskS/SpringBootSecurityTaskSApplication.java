package com.TaskS.springbootsecurityTaskS;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootSecurityTaskSApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootSecurityTaskSApplication.class, args);
	}

}
